export enum Role {
 
  Admin = "ROLE_ADMIN",
  Clerk = "ROLE_CLERK",
  Executive = "ROLE_EXECUTIVE",
  Supervisor = "ROLE_SUPERVISOR"
  
}
