export interface Category {
  id?: number,
  categoryName?: string,
  categoryCode?: string,
  description?: string,
  deleteFlag?: boolean
}
