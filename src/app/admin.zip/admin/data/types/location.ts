export interface Location {
  id?: number,
  subcounty?: string,
  ward?: string,
  locationCode?: string,
  deleteFlag?: boolean
}
