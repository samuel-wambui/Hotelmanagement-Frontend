export interface Attachment {
  name?: string,
  url?: string,
  dateAdded?: Date
}
