export interface Log {
  id?: number,
  starttime?: Date,
  username?: string,
  requesttip?: string
  activity?: string
}
