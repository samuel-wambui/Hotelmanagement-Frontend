export interface Custodian {
  id?: number;
  custodianName?: string;
  custodianCode?: string;
  email?: string;
  department?: string;
  deleteFlag: boolean;
}
