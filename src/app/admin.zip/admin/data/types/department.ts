export interface Department {
  id?: number,
  departmentName?: string,
  departmentCode?: string,
}
