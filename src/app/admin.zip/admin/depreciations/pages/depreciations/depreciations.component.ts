import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-depreciations',
  templateUrl: './depreciations.component.html',
  styleUrls: ['./depreciations.component.sass']
})
export class DepreciationsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
