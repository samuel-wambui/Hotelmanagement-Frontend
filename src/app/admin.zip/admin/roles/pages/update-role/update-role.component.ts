import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-update-role',
  templateUrl: './update-role.component.html',
  styleUrls: ['./update-role.component.sass']
})
export class UpdateRoleComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
